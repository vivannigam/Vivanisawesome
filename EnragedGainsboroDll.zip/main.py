# from tkinter import *
# tk = Tk()
# tk.geometry("200x200")
# entry = Entry(tk,font = "TNR 15 bold")
# entry.pack()
# tk.mainloop() 

# from tkinter import *
# tk = Tk()
# tk.geometry("200x200")
# tk.title("TK-Window")
# entry = Entry(tk,font = "TNR 15 bold")
# entry.pack()
# def name():
#   x = entry.get()
#   print(x)
# button = Button(tk,text = "Enter",
# width = 20,command = name)
# button.pack()
# tk.mainloop()

# from tkinter import *
# tk = Tk()
# tk.geometry("300x300")
# tk.title("TK-Window")
# entry = Entry(tk,font = "TNR 15 bold")
# entry.pack()
# def name():
#     x = entry.get()
#     print (x)
# button = Button(tk, text = "Enter",
#      width = 20,command = name)
# button.pack()
# canvas = Canvas(tk, width = 200, height = 200, bg = 'red')
# canvas.pack()
# tk.mainloop()


# from tkinter import *
# tk = Tk()
# tk.geometry("300x300")
# tk.title("TK-Window")
# entry = Entry(tk,font = "TNR 15 bold")
# entry.pack()
# def name():
#     x = entry.get()
#     print (x)
# button = Button(tk, text = "Enter",
#      width = 20,command = name)
# button.pack()
# canvas = Canvas(tk, width = 200, height = 200, bg = 'red')
# canvas.pack()
# canvas.create_text(100,100,text = 'text',
# font = 'TNR 20 bold italic')
# tk.mainloop()

# from tkinter import *
# tk = Tk()
# tk.geometry("300x300")
# tk.title("TK-Window")
# entry = Entry(tk,font = "TNR 15 bold")
# entry.pack()
# def name():
#     x = entry.get()
#     # print (x)
#     canvas.create_text(100,100,text = x,font = 'TNR 10 bold italic')
# button = Button(tk, text = "Enter",
#      width = 20,command = name)
# button.pack()
# canvas = Canvas(tk, width = 200, height = 200, bg = 'red')
# canvas.pack()
# tk.mainloop()

# from tkinter import *
# tk = Tk()
# tk.geometry("300x300")
# tk.title("TK-Window")
# entry = Entry(tk,font = "TNR 15 bold")
# entry.pack()
# def name():
#     x = entry.get()
#     canvas.delete(ALL)
#     # print (x)
#     canvas.create_text(100,100,text = x,font = 'TNR 10 bold italic')
# button = Button(tk, text = "Enter",
#      width = 20,command = name)
# button.pack()
# canvas = Canvas(tk, width = 200, height = 200, bg = 'red')
# canvas.pack()
# tk.mainloop()

# from tkinter import *
# tk = Tk()
# tk.geometry("300x300")
# tk.title("TK-Window")
# entry = Entry(tk,font = "TNR 15 bold")
# entry.pack()
# y = 10
# def name():
#   global y
#   y = y+20
#   x = entry.get()
#   # canvas.delete(ALL)
#     # print (x)
#   canvas.create_text(100,100,text = x,font = 'TNR 10 bold italic')
# button = Button(tk, text = "Enter",
#      width = 20,command = name)
# button.pack()
# canvas = Canvas(tk, width = 200, height = 200, bg = 'red')
# canvas.pack()
# tk.mainloop()

# from tkinter import *
# def grading():
#   pass
#   tk.geometry("600x300")
#   tk.title("mygradingRubics")
#   text = 'Get your grade',fg = 'red', bg = 'yellow'
#   entry = Entry(tk)
#   entry.pack()
#   button = Button(tk,text = 'Get grade',
#   fg = 'blue',bg ='red',width = 10,command = grading)
# button.pack()
# canvas = Canvas(tk, width = 200, height = 200)
# canvas.pack()
# if points 81 to 90: txt = ('Grade:\t B')
# if points 71 to 80: txt = ()

  


