# print('hello world')
# print('45')
# print('45.34')

# print(34+20)

# print('hello '*5)
# print('hello '+'25')

# student = 'neha'
# print (student)

# name = input('Tell your name:')
# lastname = input('Tell your lastname:')
# print (name, lastname)

# num1 = 5
# num2 = 10
# total = num1 + num2
# print (total)

# num1 = 34.5
# num2 = int(num1)
# num3 = float(num2)
# print(num1,num2,num3)

# n1 = input('tell a number:')
# n2 = input('tell a number:')
# total = int(n1) + int(n2)
# print('total is',total)

# hour = int(input('Tell hour:   '))
# minutes = 60
# seconds = 60
# hour_to_second = hour*minutes*seconds
# print('there are' + \
# str(hour_to_second) + \
# ' second in ' + \
# str(hour) + ' hours')

# q = input('Enter total quarters:   ')
# d = input ('Enter total dimes:   ')
# n = input ('Enter total nickels:   ')
# p = input ('Enter total pennies:   ')

# q_to_p=int(q)*25  # to convert quarters to pennies
# d_to_p=int(d)*10  # to convert dimes to pennies
# n_to_p=int(n)*5   # to convert nickels to pennies

# total_pennies=q_to_p+d_to_p+n_to_p
# total_dollars=total_pennies/100

# print('total pennies are :',total_pennies)
# print('total dollars are :',total_dollars)
