from tkinter import *
import random
def number_guess():
  pass
def new_game():
  pass
tk = Tk()
tk.title("Geuss the Number Game")
frame = Frame(tk)
frame.pack()
label = Label(frame, text = 'Enter Your Number Guess    Here',font = 'TNR 15 bold',
  fg = 'green',height = 3)
label.pack()
button1 = Button(frame, text = 'Enter',command = number_guess, width = 20, font = 'TNR 10 bold')
button1.pack()

canvas = Canvas(frame,width = 300,height = 200, bg = 'light blue')
canvas.pack()
# test now
#tes#should i make a new repl
#try reload
#it dint work


