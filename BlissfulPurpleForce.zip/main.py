from tkinter import *
import random
secret_number = random.randrange (0,101)
counter = 7
# test now
def number_guess():
  global counter, secret_number,canvas_text, canvas
  counter = counter -1
  guess = int(entry.get())
  if guess > secret_number and counter > 0:
    canvas_text= 'Remaining guess:\t'+ \
    str(counter) + '\nguess is:\t' + \
    str(guess) +'\nlower!'
    create_canvas()
def new_game():
  pass
tk = Tk()
tk.title("Geuss the Number Game")
frame = Frame(tk)
frame.pack()
label = Label(frame, text = 'Enter Your Number Guess    Here',font = 'TNR 15 bold',
  fg = 'green',height = 3)
label.pack()
button1 = Button(frame, text  = 'Enter',command =            number_guess, width = 20,   font = 'TNR 10 bold')
button1.pack()
entry = Entry(frame,font = 'bold 20')
entry.pack()

button2 = Button(frame, text ='Play again', command = new_game)
button2.pack()
button3 = Button(frame, text = 'Exit',command = tk.destroy)
button3.pack()

canvas = Canvas(frame,width = 300,height = 200, bg = 'light blue')
canvas.pack()
def create_canvas():
  global canvas_text,canvas
  canvas.delete(ALL)
  canvas.create_text(150,100, text = canvas_text,
  fill = 'red',font ='TNR 12')
  #step 10

tk.mainloop()

